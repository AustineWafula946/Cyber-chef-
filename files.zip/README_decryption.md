# AES Decryption — Python

A simple AES decryption script using **CBC mode** with PKCS7 padding, mirroring the encryption output from CyberChef.

## Requirements

```bash
pip install pycryptodome
```

## Usage

```python
from aes_decryption import aes_decrypt

plaintext = aes_decrypt(
    ciphertext_hex="5c7b032ac3c808928b44d7e80076caf07966e382a2056e5890df68b2ecaf97d9",
    key="gomycodegomycode",
    iv="1234567890123456"
)
print(plaintext)  # cybersecurity is powerful
```

## How it works

| Parameter | Value (example) |
|-----------|----------------|
| Algorithm | AES-128 |
| Mode | CBC |
| Padding | PKCS7 |
| Key | UTF-8 string (16 bytes) |
| IV | UTF-8 string (16 bytes) |
| Input | Hex-encoded ciphertext |
| Output | UTF-8 plaintext |

## Related

- [AES Encryption](../aes_encryption/aes_encryption.py) — the matching encryption script
