from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import binascii

def aes_decrypt(ciphertext_hex, key, iv, mode=AES.MODE_CBC):
    """
    Decrypt AES-encrypted data.

    Parameters:
        ciphertext_hex (str): Hex-encoded ciphertext
        key (str): Encryption key (UTF-8 string)
        iv (str): Initialization vector (UTF-8 string, required for CBC)
        mode: AES mode (default: AES.MODE_CBC)

    Returns:
        str: Decrypted plaintext
    """
    key_bytes = key.encode('utf-8')
    iv_bytes = iv.encode('utf-8')
    ciphertext = binascii.unhexlify(ciphertext_hex)

    cipher = AES.new(key_bytes, mode, iv_bytes)
    decrypted = unpad(cipher.decrypt(ciphertext), AES.block_size)
    return decrypted.decode('utf-8')


if __name__ == "__main__":
    # --- Example usage (matches the encryption settings from CyberChef) ---
    KEY = "gomycodegomycode"          # 16-byte key (AES-128)
    IV  = "1234567890123456"          # 16-byte IV
    CIPHERTEXT_HEX = "5c7b032ac3c808928b44d7e80076caf07966e382a2056e5890df68b2ecaf97d9"

    plaintext = aes_decrypt(CIPHERTEXT_HEX, KEY, IV)
    print(f"Decrypted text: {plaintext}")
